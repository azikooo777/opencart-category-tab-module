<?php
// Heading
$_['heading_title'] = 'Tabs Category';