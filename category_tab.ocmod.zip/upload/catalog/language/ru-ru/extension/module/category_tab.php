<?php
// Heading
$_['heading_title'] = 'Категория Табов';